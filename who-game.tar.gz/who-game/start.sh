#!/bin/bash
DIR="$(cd "$(dirname "$0")" && pwd)"
cd "${DIR}/app/.."
nohup python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 > uvicorn.log 2>&1 &
echo $! > uvicorn.pid
IP=$(hostname -I 2>/dev/null | awk '{print $1}' || echo "localhost")
echo "服务已启动 (PID: $(cat uvicorn.pid))"
echo "访问: http://${IP}:8000"
echo "日志: tail -f uvicorn.log"
