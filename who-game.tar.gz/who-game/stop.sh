#!/bin/bash
DIR="$(cd "$(dirname "$0")" && pwd)"
PID_FILE="${DIR}/uvicorn.pid"
if [ -f "${PID_FILE}" ]; then
    PID=$(cat "${PID_FILE}")
    kill "${PID}" 2>/dev/null && echo "服务已停止 (PID: ${PID})" || echo "进程不存在"
    rm -f "${PID_FILE}"
else
    echo "未找到 PID 文件"
fi
